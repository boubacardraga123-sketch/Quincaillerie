# Guide : publier l'app Quincaillerie Diallo comme logiciel Windows via GitHub

Ce dossier contient tout ce qu'il faut pour transformer ton app HTML en
véritable application de bureau Windows (.exe), construite automatiquement
par GitHub — sans que tu aies besoin d'installer Electron sur ton PC.

## Étape 1 — Créer le dépôt GitHub

1. Va sur https://github.com/new
2. Nom du dépôt : `quincaillerie-diallo`
3. Laisse-le en **Public** ou **Privé**, comme tu préfères
4. Ne coche PAS "Add a README" (on a déjà nos fichiers)
5. Clique sur "Create repository"

## Étape 2 — Envoyer les fichiers sur GitHub

Sur ton PC, ouvre un terminal (ou Git Bash) dans le dossier `quincaillerie-diallo`
téléchargé, puis tape :

```
git init
git add .
git commit -m "Première version de l'app"
git branch -M main
git remote add origin https://github.com/TON-NOM-UTILISATEUR/quincaillerie-diallo.git
git push -u origin main
```

(Remplace `TON-NOM-UTILISATEUR` par ton nom d'utilisateur GitHub.)

## Étape 3 — Déclencher la construction de l'installeur

Le fichier `.github/workflows/build.yml` dit à GitHub : "à chaque fois que
je pousse une étiquette de version (tag), construis l'installeur Windows."

Pour déclencher la première construction :

```
git tag v1.0.0
git push origin v1.0.0
```

GitHub va automatiquement :
- installer Node.js et Electron
- construire ton app
- créer un installeur `.exe`
- le publier dans une "Release" sur GitHub, prête à télécharger

Tu peux suivre la progression dans l'onglet **Actions** de ton dépôt GitHub
(ça prend 2 à 4 minutes).

## Étape 4 — Télécharger et installer

Une fois terminé :
1. Va dans l'onglet **Releases** de ton dépôt GitHub (à droite de la page)
2. Télécharge le fichier `.exe`
3. Double-clique dessus sur n'importe quel PC Windows pour installer l'app

Chaque utilisateur qui installe l'app aura une icône sur le Bureau et dans
le menu Démarrer, "Quincaillerie Diallo", qui ouvre l'app comme un vrai
logiciel (pas dans un navigateur).

## Pour publier une mise à jour plus tard

Modifie `index.html` si besoin, puis :

```
git add .
git commit -m "Mise à jour"
git push
git tag v1.0.1
git push origin v1.0.1
```

Un nouvel installeur `.exe` sera généré automatiquement.

## Note sur les données

L'app stocke toutes les données localement dans le navigateur intégré
(comme actuellement). Les données restent sur l'ordinateur où l'app est
installée et ne se synchronisent pas entre plusieurs PC — comme c'était
déjà le cas.

## Icône personnalisée (plus tard)

Si tu veux changer l'icône, remplace le fichier `build/icon.png` par une
image carrée (au moins 256×256 pixels), puis republie une nouvelle version.
